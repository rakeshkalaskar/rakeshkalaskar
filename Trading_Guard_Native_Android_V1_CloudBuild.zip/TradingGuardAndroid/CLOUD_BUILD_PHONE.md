# Build the APK from your Android phone (no Android Studio)

This project contains a GitHub Actions workflow that builds the APK in GitHub's cloud.

## Phone-only steps

1. Create/sign in to a GitHub account at https://github.com/
2. Create a NEW repository. Example name: `trading-guard-android`.
3. Keep the repository private if possible.
4. From the repository page, choose **Add file → Upload files**.
5. Upload the contents of this `TradingGuardAndroid` folder (including `.github/workflows/build-apk.yml`).
6. Commit the files to `main`.
7. Open the repository's **Actions** tab.
8. Open **Build Trading Guard APK**.
9. Tap **Run workflow** if it has not already started.
10. Wait for the green check mark.
11. Open the completed workflow run and scroll to **Artifacts**.
12. Download `trading-guard-debug-apk`.
13. Extract it and install `app-debug.apk` on your Android phone.

## Important

- Do NOT upload your Groww token, API key, API secret, TOTP, or passwords to GitHub.
- Enter the Groww token only inside the installed Trading Guard app.
- Because a Groww credential was previously exposed in chat, revoke/regenerate it before using the app.
- This is a debug APK for personal testing, not a Play Store release.
