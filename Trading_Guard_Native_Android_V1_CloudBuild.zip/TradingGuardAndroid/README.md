# Trading Guard — Native Android V1

A native Android starter app for monitoring Groww through the official Groww Trading API. It does not embed any credentials.

## What it does
- Native Android UI; no Chrome/content:// page and no local Flask server.
- Stores the Groww access token encrypted with Android Keystore-backed AES-GCM.
- Foreground monitoring service.
- Polls Groww positions and order history for CASH and FNO.
- Counts unique completed exchange trades/fills by querying each executed order's trade list.
- Calculates approximate live P&L using realised P&L plus LTP-based unrealised P&L.
- Rules: loss limit, profit lock, max completed trades, max stop-loss trades, max consecutive-loss events, max active positions.
- Kill switch locks the guard and can cancel open/pending orders.
- Persistent lock until the user explicitly unlocks with PIN.
- Does NOT automatically close live positions in this version.

## Important Groww notes
Groww's current API docs say API access tokens expire daily at 6:00 AM and that the Trading API supports CASH and FNO, not MCX. See the official docs.

## Build
Open the project in Android Studio and build `app` -> APK. The project targets Android API 36 and uses only Android framework APIs plus the Android Gradle plugin.

## First use
1. Open Trading Guard.
2. Enter your Groww access token locally. Never paste it into ChatGPT or source code.
3. Tap Save & Test.
4. Configure rules.
5. Set a PIN.
6. Start Guard.
7. Keep the persistent notification enabled and exclude the app from aggressive battery optimization if Android asks.

## Security
A Groww credential previously exposed in chat should be revoked/regenerated before use. This project contains no real token or secret.

## Cloud APK build (no Android Studio)
The repository includes `.github/workflows/build-apk.yml`. Upload the project to a GitHub repository and run **Build Trading Guard APK** from the Actions tab. The workflow builds `app-debug.apk` in GitHub's cloud and uploads it as an artifact. See `CLOUD_BUILD_PHONE.md`.
