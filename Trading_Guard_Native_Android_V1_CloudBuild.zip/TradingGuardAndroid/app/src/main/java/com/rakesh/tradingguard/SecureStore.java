package com.rakesh.tradingguard;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public final class SecureStore {
    private static final String KS="AndroidKeyStore", ALIAS="TradingGuardKey";
    private static final String PREF="guard_secure";
    private final Context c;
    public SecureStore(Context c){this.c=c.getApplicationContext();}
    private SecretKey key() throws Exception{
        KeyStore ks=KeyStore.getInstance(KS); ks.load(null);
        if(!ks.containsAlias(ALIAS)){
            KeyGenerator kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,KS);
            kg.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
            kg.generateKey();
        }
        return ((KeyStore.SecretKeyEntry)ks.getEntry(ALIAS,null)).getSecretKey();
    }
    public void putToken(String token){try{
        Cipher cp=Cipher.getInstance("AES/GCM/NoPadding"); cp.init(Cipher.ENCRYPT_MODE,key());
        String iv=Base64.encodeToString(cp.getIV(),Base64.NO_WRAP), ct=Base64.encodeToString(cp.doFinal(token.getBytes(StandardCharsets.UTF_8)),Base64.NO_WRAP);
        prefs().edit().putString("iv",iv).putString("ct",ct).apply();
    }catch(Exception e){throw new RuntimeException(e);}}
    public String getToken(){try{
        String iv=prefs().getString("iv",null),ct=prefs().getString("ct",null); if(iv==null||ct==null)return "";
        Cipher cp=Cipher.getInstance("AES/GCM/NoPadding"); cp.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(iv,Base64.NO_WRAP)));
        return new String(cp.doFinal(Base64.decode(ct,Base64.NO_WRAP)),StandardCharsets.UTF_8);
    }catch(Exception e){return "";}}
    public void clear(){prefs().edit().clear().apply();}
    private SharedPreferences prefs(){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE);}
}
