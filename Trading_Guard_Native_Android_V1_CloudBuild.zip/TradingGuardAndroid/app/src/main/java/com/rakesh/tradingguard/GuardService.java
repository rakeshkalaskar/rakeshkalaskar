package com.rakesh.tradingguard;

import android.app.*;import android.content.*;import android.os.*;
import org.json.*;import java.text.*;import java.util.*;import java.util.concurrent.*;

public class GuardService extends Service {
    private ScheduledExecutorService exec; private volatile boolean running; private SecureStore store; private SharedPreferences p;
    private static final String PREF="guard_state"; private static final int NOTIF=42;
    @Override public void onCreate(){super.onCreate();store=new SecureStore(this);p=getSharedPreferences(PREF,MODE_PRIVATE);}
    @Override public int onStartCommand(Intent i,int flags,int id){startFg(); if(!running){running=true;exec=Executors.newSingleThreadScheduledExecutor();exec.scheduleWithFixedDelay(this::poll,0,5,TimeUnit.SECONDS);}return START_STICKY;}
    private void startFg(){String ch="guard";NotificationManager nm=getSystemService(NotificationManager.class); if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel(ch,"Trading Guard",NotificationManager.IMPORTANCE_LOW));
        Notification n=new Notification.Builder(this,ch).setSmallIcon(android.R.drawable.ic_lock_lock).setContentTitle("Trading Guard active").setContentText("Monitoring Groww trading activity").setOngoing(true).build();startForeground(NOTIF,n);}
    private void poll(){try{
        String token=store.getToken(); if(token.isEmpty())return; GrowwApi api=new GrowwApi(token);
        double pnl=0; int active=0; List<String> newOrders=new ArrayList<>();
        for(String seg:new String[]{"CASH","FNO"}){
            JSONObject pos=api.get("/v1/positions/user?segment="+seg); JSONArray pa=GrowwApi.arr(pos,"positions");
            if(pa!=null)for(int j=0;j<pa.length();j++){JSONObject q=pa.getJSONObject(j);int qty=q.optInt("quantity",0);if(qty!=0)active++;pnl+=GrowwApi.num(q,"realised_pnl");}
            JSONObject ord=api.get("/v1/order/list?segment="+seg+"&page=0&page_size=100");JSONArray oa=GrowwApi.arr(ord,"order_list");
            if(oa!=null)for(int j=0;j<oa.length();j++){JSONObject q=oa.getJSONObject(j);String oid=GrowwApi.str(q,"groww_order_id");String st=GrowwApi.str(q,"order_status");if(!oid.isEmpty())newOrders.add(seg+"|"+oid+"|"+st+"|"+GrowwApi.str(q,"order_type"));}
        }
        // LTP-based unrealised P&L, batched by segment (up to 50 symbols per Groww request).
        for(String seg:new String[]{"CASH","FNO"}){
            JSONObject pos=api.get("/v1/positions/user?segment="+seg);JSONArray pa=GrowwApi.arr(pos,"positions"); if(pa==null)continue;
            List<String> syms=new ArrayList<>();List<JSONObject> ps=new ArrayList<>();
            for(int j=0;j<pa.length();j++){JSONObject q=pa.getJSONObject(j);if(q.optInt("quantity",0)!=0&&q.optString("exchange","").length()>0){syms.add(q.optString("exchange")+"_"+q.optString("trading_symbol"));ps.add(q);}}
            for(int off=0;off<syms.size();off+=50){int end=Math.min(off+50,syms.size());StringBuilder sb=new StringBuilder();for(int k=off;k<end;k++){if(k>off)sb.append(',');sb.append(URLEncoder.encode(syms.get(k),"UTF-8"));}
                JSONObject l=api.get("/v1/live-data/ltp?segment="+seg+"&exchange_symbols="+sb);JSONObject lp=l.optJSONObject("payload");if(lp!=null)for(int k=off;k<end;k++){JSONObject q=ps.get(k);double last=lp.optDouble(syms.get(k),Double.NaN);double avg=q.optDouble("net_price",0);int qty=q.optInt("quantity",0);if(!Double.isNaN(last))pnl+=(last-avg)*qty;}
            }
        }
        int trades=0,sl=0; Set<String> seen=new HashSet<>(); String today=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());
        for(String row:newOrders){String[] a=row.split("\\|",-1);if(a.length<4)continue;String oid=a[1],st=a[2],ot=a[3];if(!"EXECUTED".equals(st)&&!"DELIVERY_AWAITED".equals(st))continue;String seg=a[0];try{JSONObject tr=api.get("/v1/order/trades/"+oid+"?segment="+seg+"&page=0&page_size=50");JSONArray ta=GrowwApi.arr(tr,"trade_list");if(ta!=null)for(int k=0;k<ta.length();k++){JSONObject t=ta.getJSONObject(k);String tid=t.optString("groww_trade_id");if(tid.isEmpty()||!seen.add(tid))continue;trades++;if("SL".equalsIgnoreCase(ot))sl++;}}catch(Exception ignored){}}
        double base=p.getFloat("baseline",Float.NaN); if(Float.isNaN((float)base)){base=pnl;p.edit().putFloat("baseline",(float)pnl).apply();}
        double session=pnl-base; int prevLoss=p.getInt("loss_streak",0); double prevPnl=p.getFloat("last_pnl",Float.NaN);int streak=prevLoss;
        if(!Float.isNaN((float)prevPnl)&&trades>p.getInt("last_trades",0)){if(pnl<prevPnl)streak++;else if(pnl>prevPnl)streak=0;}
        p.edit().putFloat("pnl",(float)pnl).putFloat("session_pnl",(float)session).putInt("active",active).putInt("trades",trades).putInt("sl",sl).putInt("loss_streak",streak).putFloat("last_pnl",(float)pnl).putInt("last_trades",trades).putLong("updated",System.currentTimeMillis()).apply();
        evaluate(api,newOrders,session,trades,sl,streak,active);
    }catch(Exception e){p.edit().putString("error",e.getMessage()==null?e.toString():e.getMessage()).putLong("updated",System.currentTimeMillis()).apply();}}
    private void evaluate(GrowwApi api,List<String> orders,double session,int trades,int sl,int streak,int active){if(p.getBoolean("locked",false))return;double loss=p.getFloat("loss_limit",2000),profit=p.getFloat("profit_lock",2000);int mt=p.getInt("max_trades",2),ms=p.getInt("max_sl",1),mc=p.getInt("max_consecutive",2),mp=p.getInt("max_positions",1);String reason=null;
        if(loss>0&&session<=-loss)reason="Loss limit reached";else if(profit>0&&session>=profit)reason="Profit lock reached";else if(mt>0&&trades>=mt)reason="Maximum completed trades reached";else if(ms>0&&sl>=ms)reason="Stop-loss trade limit reached";else if(mc>0&&streak>=mc)reason="Consecutive-loss limit reached";else if(mp>0&&active>mp)reason="Maximum active positions reached";
        if(reason!=null){p.edit().putBoolean("locked",true).putString("reason",reason).apply(); if(p.getBoolean("cancel_orders",true))for(String row:orders){String[] a=row.split("\\|",-1);if(a.length<3)continue;if(!"OPEN".equals(a[2])&&!"TRIGGER_PENDING".equals(a[2])&&!"NEW".equals(a[2])&&!"ACKED".equals(a[2]))continue;try{api.post("/v1/order/cancel","{\"segment\":\""+a[0]+"\",\"groww_order_id\":\""+a[1]+"\"}");}catch(Exception ignored){}}notifyLocked(reason);}}
    private void notifyLocked(String reason){NotificationManager nm=getSystemService(NotificationManager.class);String ch="guard";Notification n=new Notification.Builder(this,ch).setSmallIcon(android.R.drawable.ic_lock_lock).setContentTitle("Trading Guard: LOCKED").setContentText(reason).setOngoing(true).build();nm.notify(NOTIF+1,n);}
    @Override public void onDestroy(){running=false;if(exec!=null)exec.shutdownNow();super.onDestroy();}
    @Override public android.os.IBinder onBind(Intent i){return null;}
}
