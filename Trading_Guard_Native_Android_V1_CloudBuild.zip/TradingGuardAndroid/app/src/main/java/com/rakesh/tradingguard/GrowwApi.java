package com.rakesh.tradingguard;

import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public final class GrowwApi {
    private static final String BASE="https://api.groww.in";
    private final String token;
    public GrowwApi(String token){this.token=token;}
    public JSONObject get(String path) throws Exception{return request("GET",path,null);}
    public JSONObject post(String path,String body) throws Exception{return request("POST",path,body);}
    private JSONObject request(String method,String path,String body)throws Exception{
        HttpURLConnection x=(HttpURLConnection)new URL(BASE+path).openConnection();
        x.setRequestMethod(method); x.setConnectTimeout(8000); x.setReadTimeout(10000);
        x.setRequestProperty("Accept","application/json"); x.setRequestProperty("Authorization","Bearer "+token); x.setRequestProperty("X-API-VERSION","1.0");
        if(body!=null){x.setDoOutput(true);x.setRequestProperty("Content-Type","application/json");try(OutputStream o=x.getOutputStream()){o.write(body.getBytes(StandardCharsets.UTF_8));}}
        int code=x.getResponseCode(); InputStream is=code>=200&&code<400?x.getInputStream():x.getErrorStream();
        String s=read(is); if(code<200||code>=300) throw new IOException("Groww HTTP "+code+": "+s); return new JSONObject(s);
    }
    private static String read(InputStream is)throws Exception{if(is==null)return "";StringBuilder b=new StringBuilder();try(BufferedReader r=new BufferedReader(new InputStreamReader(is,StandardCharsets.UTF_8))){String l;while((l=r.readLine())!=null)b.append(l);}return b.toString();}
    public static JSONArray arr(JSONObject r,String key){try{return r.getJSONObject("payload").optJSONArray(key);}catch(Exception e){return null;}}
    public static double num(JSONObject o,String k){Object v=o.opt(k);return v instanceof Number?((Number)v).doubleValue():0;}
    public static String str(JSONObject o,String k){return o.optString(k,"");}
}
